﻿using System;


IAutomobileFactory sedanFactory = new SedanFactory();
IAutomobileFactory suvFactory = new SUVFactory();
IAutomobileFactory truckFactory = new TruckFactory();

IAutomobile sedan = sedanFactory.CreateAutomobile();
IAutomobile suv = suvFactory.CreateAutomobile();
IAutomobile truck = truckFactory.CreateAutomobile();

Console.WriteLine(sedan.GetModelInfo());
Console.WriteLine("\n");

Console.WriteLine(suv.GetModelInfo());
Console.WriteLine("\n");

Console.WriteLine(truck.GetModelInfo());
Console.WriteLine("\n");


interface IAutomobile
{
    string GetModelInfo();
}


interface IAutomobileFactory
{
    IAutomobile CreateAutomobile();
}




// не знала какие у них плюсы и минусы пришлось в интернете искать
public class Sedan : IAutomobile
{
    public string GetModelInfo()
    {
        return "Model(Type): Sedan" +
               "\nInformation: Interior and Trunk are separated ";
    }
}


public class SUV : IAutomobile
{
    public string GetModelInfo()
    {
        return "Model(type): SUV" +
               "\nInformation: Possibility of all-wheel drive";
    }
}


public class Truck : IAutomobile
{
    public string GetModelInfo()
    {
        return "Model(Type): Truck" +
               "\nInformation: Huge and big";
    }
}



class SedanFactory : IAutomobileFactory
{
    public IAutomobile CreateAutomobile()
    {
        return new Sedan();
    }
}


class SUVFactory : IAutomobileFactory
{
    public IAutomobile CreateAutomobile()
    {
        return new SUV();
    }
}


class TruckFactory : IAutomobileFactory
{
    public IAutomobile CreateAutomobile()
    {
        return new Truck();
    }
}



